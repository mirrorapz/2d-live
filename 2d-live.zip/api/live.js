export default function handler(req, res) {
  const liveData = {
    time: new Date().toLocaleTimeString(),
    morning: "12.34",
    evening: "56.78",
    updated: new Date().toISOString()
  };

  res.status(200).json(liveData);
}
